import { Component, OnInit } from '@angular/core';
import { IBook } from './IBook';
import { BookserviceService } from '../bookservice.service';


@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BooksComponent implements OnInit {

  constructor(private bookservice:BookserviceService) { }
  books:IBook[];
  ngOnInit() {
    this.getBookList();
  }

  getBookList(){
    this.bookservice.getBookList().subscribe(book=>this.books=book);
  }

}
