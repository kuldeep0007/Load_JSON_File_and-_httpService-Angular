import { Injectable ,OnInit} from '@angular/core';
import { IBook } from './books/IBook';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BookserviceService {

  constructor(private http: HttpClient) { }

  ngOnInit() {
    this.getBookList();
  }

  public url = '../assets/booklist.json';

  /** GET heroes from the server */
  getBookList(): Observable<IBook[]> {
    return this.http.get<IBook[]>(this.url);
  }

}
